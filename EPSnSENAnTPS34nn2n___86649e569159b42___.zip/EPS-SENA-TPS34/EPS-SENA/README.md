# EPS-SENA
Se requiere de un equipo de profesionales en el sector de la tecnología para que desarrolle un sistema de información completo. 

Metodologia de Desarrollo:
SCRUM
Lenguaje:JAVA
DB:MYSQL
